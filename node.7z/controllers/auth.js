const asyncHandler = require('../middleware/async');
const createError = require('http-errors');
const User = require('../models/User.model');
const { authSchema } = require('../helpers/validation_schema');
const {
  signAccessToken,
  signRefreshToken,
  verifyRefreshToken,
} = require('../helpers/jwt_helper');

// @desc    Register user
// @route   POST /api/v1/auth/register
// @access  Public
exports.register = asyncHandler(async (req, res, next) => {
  try {
    const result = await authSchema.validateAsync(req.body);

    const doesExist = await User.findOne({ email: result.email });
    if (doesExist)
      throw createError.Conflict(`${result.email} is already been registered`);

    const user = await User.create({
      email: result.email,
      password: result.password,
    });

    const accessToken = await signAccessToken(user.id);
    const refreshToken = await signRefreshToken(user.id);
    res.status(200).json({
      success: true,
      accessToken,
      refreshToken,
    });
  } catch (error) {
    if (error.isJoi === true) error.status = 422;
    next(error);
  }
});

exports.login = asyncHandler(async (req, res, next) => {
  try {
    const result = await authSchema.validateAsync(req.body);
    const user = await User.findOne({ email: result.email }).select(
      '+password'
    );

    if (!user) throw createError.NotFound('User not registered');

    const isMatch = await user.isValidPassword(result.password);

    if (!isMatch) throw createError.Unauthorized('Username/Password not valid');

    const accessToken = await signAccessToken(user.id);
    const refreshToken = await signRefreshToken(user.id);

    res.status(201).json({
      success: true,
      accessToken,
      refreshToken,
    });
  } catch (error) {
    if (error.isJoi === true)
      return next(createError.BadRequest('Invalid Username or Password'));
    next(error);
  }
});

exports.refreshToken = asyncHandler(async (req, res, next) => {
  const { refreshToken } = req.body;
  if (!refreshToken) throw createError.BadRequest();

  const userId = await verifyRefreshToken(refreshToken);
  const accessToken = await signAccessToken(userId);
  const refToken = await signRefreshToken(userId);

  res.status(200).json({
    success: true,
    accessToken,
    refreshToken: refToken,
  });
});

// @desc    Get current logged in user
// @route   GET /api/v1/auth/me
// @access  Private
exports.getMe = asyncHandler(async (req, res, next) => {
  console.log(req.payload);
  const user = await User.findById(req.payload.id);
  res.status(200).json({
    success: true,
    data: user,
  });
});
